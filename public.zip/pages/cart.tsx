import type { NextPage } from 'next'

const Cart: NextPage = () => {
  return (
    <div>
      Cart Page
    </div>
  )
}

export default Cart
