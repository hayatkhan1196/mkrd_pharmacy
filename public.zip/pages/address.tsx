import type { NextPage } from 'next'

const Address: NextPage = () => {
  return (
    <div>
      Address Page
    </div>
  )
}

export default Address
