import type { NextPage } from 'next'
import { Button } from 'reactstrap';
import styles from 'styles/Home.module.scss'
import useLocalize from 'i18n/i18n';


const Home: NextPage = () => {
  const { localize } = useLocalize();
  return (
    <div className={styles.container}>
      Home Page inside app!
      <Button color="info">{localize('test', { count: 1 })} example</Button>
    </div>
  )
}

export default Home
