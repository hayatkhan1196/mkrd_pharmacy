import React from 'react'
import {makeStore as store, wrapper} from "../redux/store"
import { Provider } from 'react-redux';

// Css files
import 'styles/globals.scss'

import Layout from '../components/Layout/Layout'

function MyApp({ Component, pageProps }) {
  return (
    <React.StrictMode>
      <Provider store={store()}>
        <Layout>
          <Component {...pageProps} />
        </Layout>
      </Provider>
    </React.StrictMode>
  )
}

export default wrapper.withRedux(MyApp);
