import type { NextPage } from 'next'

const Prescription: NextPage = () => {
  return (
    <div>
      Prescription Page
    </div>
  )
}

export default Prescription
