import type { NextPage } from 'next'

const Medicine: NextPage = () => {
  return (
    <div>
      Medicine (Items) Page
    </div>
  )
}

export default Medicine
