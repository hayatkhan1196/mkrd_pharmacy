import Images from "components/ReUseableComponents/Images";
import ListingCard from "components/ReUseableComponents/ListingCard";
import { useEffect } from "react";
import { useInView } from "react-intersection-observer";

import { useSelector } from "react-redux";

const Medicines = () => {
  const searchResult = useSelector((state) => state.search.searchResult)
   // for infinite scroll observer
  const { ref, inView } = useInView({
    threshold: 0,
    initialInView: false
  });
  // fetch next page data
  useEffect(() => {
    console.log("(inview) call next page api here -----", inView)
    // call next page api here
  }, [inView])
  
  return (
    <main className="container listing-page container-fluid ">
      <div className="row">
        {/* <Filters /> */}
        <div className="col-lg-1"></div>
        <div className="col-lg-7">
          {
            searchResult.map((value, key) => {
              let isLast = false;
              if (key + 1 === searchResult.length) {
                isLast = true;
              }
              return(
                <>
                  <ListingCard 
                    key={key}
                    name={value.name}
                    manufacturer={value.manufacturer_name}
                    image={value.images[0].url}
                    mrp={value.mrp}
                    rx={value.is_rx_required}
                  />
                  {/* for infinite scroll observer */}
                  {isLast === true && <div style={{height:20}} ref={ref}></div>}
                </>
              )
            })
          }
          {/* {
            inView &&
            <div className="text-center">
              <div className="spinner-border text-dark" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            </div>
          } */}
        </div>
        <div className="col-lg-3 col-3 box-shadow-bg third">
          <div className="row d-flex justify-content-between mb-5">
            <div className="col-lg-8">
              <p className="cart-medicines p-3 ">Your cart is empty</p>
              <button
                className="view-cart"
                style={{ width: 100, border: "none", background: "tranparent" }}
              >
                View Cart
              </button>
            </div>
            <div className="col-lg-4 col-3">
              <img
                width={57.96}
                height={57.96}
                style={{ float: "right" }}
                src="/assets/Medicines.png"
                alt="cart mediciene"
              />
            </div>
          </div>
          <div
            style={{ padding: 15, marginLeft: -10, marginTop: 10 }}
            className="right-cart-medicines box-shadow-bg"
          >
            <div className="right-card2">
              <p className="cart-medicines mt-3 mb-0">Save your time</p>
              <Images
                width={40.96}
                height={57.96}
                src="/assets/Clipboard.png"
                alt="cart mediciene"
              />
            </div>
            <h5>Order Quickely</h5>
            <p className="medicine-card-text">
              Upload doctor&apos;s prescription and we will add the medicines for
              you!
            </p>
            <button type="button" className="btn btn-white shadow-none">
              <p>Upload</p>
            </button>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Medicines;
