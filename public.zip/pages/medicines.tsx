import Filters from "components/ListingPage/Filters/Filters";
import Listing from "components/ListingPage/MedicineList/Listing";
import Images from "components/ReUseableComponents/Images";
import type { NextPage } from "next";

const Medicines: NextPage = () => {
  return (
    <main className="container listing-page container-fluid ">
      <div className="row">
        {/* <Filters /> */}
        <div className="col-lg-1"></div>
        <Listing />
        <div className="col-lg-3 col-3 box-shadow-bg third">
          <div className="row d-flex justify-content-between mb-5">
            <div className="col-lg-8">
              <p className="cart-medicines p-3 ">Your cart is empty</p>
              <button
                className="view-cart"
                style={{ width: 100, border: "none", background: "tranparent" }}
              >
                View Cart
              </button>
            </div>
            <div className="col-lg-4 col-3">
              <img
                width={57.96}
                height={57.96}
                style={{ float: "right" }}
                src="/assets/Medicines.png"
                alt="cart mediciene"
              />
            </div>
          </div>
          <div
            style={{ padding: 15, marginLeft: -10, marginTop: 10 }}
            className="right-cart-medicines box-shadow-bg"
          >
            <div className="right-card2">
              <p className="cart-medicines mt-3 mb-0">Save your time</p>
              <Images
                width={40.96}
                height={57.96}
                src="/assets/Clipboard.png"
                alt="cart mediciene"
              />
            </div>
            <h5>Order Quickely</h5>
            <p className="medicine-card-text">
              Upload doctor's prescription and we will add the medicines for
              you!
            </p>
            <button type="button" className="btn btn-white shadow-none">
              <p>Upload</p>
            </button>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Medicines;
