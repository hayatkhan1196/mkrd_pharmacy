import ListingCard from "components/ReUseableComponents/ListingCard";
import React from "react";

const Listing = () => {
  return (
    <div className="col-lg-7">
      <ListingCard />
      <ListingCard />
      <ListingCard />
      <ListingCard />
      <ListingCard />
      <ListingCard />
    </div>
  );
};

export default Listing;
