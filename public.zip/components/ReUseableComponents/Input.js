import React from "react";
import { Input } from "reactstrap";

const Inputs = ({
  placeholder,
  type,
  name,
  id,
  value,
  setState,
  onFocus,
  onBlur,
  onChange,
}) => {
  return (
    <Input
      placeholder={placeholder}
      type={type}
      name={name}
      id={id}
      value={value}
      onChange={onChange ? (e) => onChange(e) : (e) => setState(e.target.value)}
      onFocus={onFocus}
      onBlur={onBlur}
    />
  );
};

export default Inputs;
