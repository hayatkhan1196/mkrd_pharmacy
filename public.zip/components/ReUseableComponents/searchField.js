import React from "react";
import Images from "./Images";

const SearchField = ({ placeholder }) => {
  return (
    <div className="global-search-bar">
      <div className="d-flex justify-content-center align-items-center">
        <button
          style={{
            display: "flex",
            alignItems: "center",
            minHeight: "17.5px",
          }}
        >
          <Images src="/assets/search.svg" alt="Logo" width={20} height={20} />{" "}
        </button>
        <input placeholder={placeholder} type="text" />
      </div>
    </div>
  );
};

export default SearchField;
