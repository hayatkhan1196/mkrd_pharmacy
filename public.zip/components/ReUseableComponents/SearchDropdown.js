import Image from "next/image";
import React from "react";
import Images from "./Images";

const SearchDropdown = (props) => {
  return (
    <>
      {props.data &&
        props.data.map((value, key) => {
          return (
            key < 4 && 
            
              <li key={key} className="list-group-item   d-flex justify-content-between" >
                {props.search === "" ? (
                  <>
                    {value.name ?? value.keyword}
                    <Images width={9.73} height={9.73} src="/assets/history-icon.svg" />
                  </>
                ) : (
                  <>
                    <div className="row query-search d-flex justify-content-between align-items-center">
                      <div className="col-lg-2">
                        <img src={value.images[0].url} alt="" width={24} />
                      </div>
                      <div className="col-lg-10">
                        <h6>{value.name_web}</h6>
                        <p>
                          {value.package_size} {value.uom === "units" ? "" : value.uom} &nbsp;<span className="text-capitalize"> {value.content.toLowerCase()}</span>(s)&nbsp;in {value.package_type}
                        </p>
                        {value.is_assured && (
                          <div className="row d-flex  verified-doc justify-content-center align-items-center">
                            <div className="col-lg-2">
                              <img src="/assets/doctor-icon.svg" alt="" />
                            </div>
                            <div className="col-lg-10">
                              <h5>Dr. Assured</h5>
                            </div>
                          </div> 
                        )}
                      </div>
                    </div>
                    <Images width={9.73} height={9.73} src="/assets/history-icon.svg" />
                  </>
                )}
              </li>
            
          );
        }
        )}
       </>

  );
};

export default SearchDropdown;
