import { useRef, useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Navbar,
  NavbarBrand,
  Nav,
  NavItem,
  Collapse,
  NavLink,
  NavbarToggler,
  Input,
} from "reactstrap";
import Dropdown from "../ReUseableComponents/DropDown";
import Images from "../ReUseableComponents/Images";
// import Input from "../ReUseableComponents/Input";
import SearchDropdown from "../ReUseableComponents/SearchDropdown";
import save_addresses from "../../JSON_DATA/save_addresses.json";
import searchData from "../../JSON_DATA/searchBar.json";

import {
  deleteSearchKeyword,
  getSearchKeyword,
  getSearchResult,
  getTrendingProductList,
} from "redux/action/searchAction";
import Link from "next/link";
import { getAddress } from "redux/action/AddressAction";

export default function Header() {
  const [showData, setshowData] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [error, setError] = useState();
  const [pinCode, setpinCode] = useState("");
  const [focus, setfocus] = useState(false);
  const dispatch = useDispatch();
  const trendingProducts = useSelector((state) => state.search.trendingItems);
  const searchResult = useSelector((state) => state.search.searchResult);
  const pincodeError = useSelector((state) => state.address?.error);
  const pincodeAddress = useSelector((state) => state.address?.pinCodeAddress);
  const [showAddress, setShowAddress] = useState(pincodeAddress);
  const searchKeywords = useSelector((state) => state.search.searchKeywords);

  const [searchQuery, setSearchQuery] = useState("");
  // get search result
  useEffect(() => {
    if (searchQuery !== "") {
      dispatch(getSearchResult(searchQuery));
    }
    if (pinCode !== "") {
      dispatch(getAddress(pinCode));
    }
    setShowAddress(pincodeAddress);
    setError(pincodeError);
    if (pincodeAddress.length > 0) {
      setError("");
    }
  }, [
    searchQuery,
    dispatch,
    pinCode,
    showAddress,
    pincodeAddress,
    pincodeError,
  ]);

  const DOM_PINCODEBOC = useRef(null);
  const handleDropdownOnClick = (dropdown, classname) => {
    if (dropdown) {
      dropdown.classList.toggle(classname);
    }
  };
  useEffect(() => {
    if (save_addresses.length > 0) {
      setshowData(true);
    }
  }, [showData, isLoggedIn]);

  // Fetch trending products
  useEffect(() => {
    dispatch(getTrendingProductList());
    dispatch(getSearchKeyword());
  }, [dispatch]);

  return (
    <>
      <header className="mdk-header d-flex align-items-center px-5">
        <Navbar
          className="d-flex  justify-content-space-between align-items-center "
          expand="md"
          style={{ width: "100%" }}
        >
          <NavbarBrand href="/">
            {" "}
            <Images
              src="/assets/medcart-logo.svg"
              alt="Logo"
              width={175}
              height={42}
            />
          </NavbarBrand>
          <div
            className="search-bar row d-flex py-8 px-12"
            style={{ width: "100%", height: 50, outline: "none" }}
          >
            <div
              className="div left col-2 d-flex justify-content-center align-items-center user-select-cursor"
              onClick={() => {
                if (
                  DOM_PINCODEBOC &&
                  DOM_PINCODEBOC.current &&
                  handleDropdownOnClick
                ) {
                  handleDropdownOnClick(DOM_PINCODEBOC.current, "active");
                }
              }}
            >
              <span className="me-3 mt-1">
                {showAddress.city
                  ? `${showAddress.city} ${pincodeAddress.state}`
                  : "Pincode"}
              </span>
              <img src="/assets/Icon.svg" alt="DropDownIcon" />
            </div>
            <div className="right col-9 ">
              <div className="d-flex justify-content-center align-items-center">
                <Input
                  placeholder="Search medicines / health care products"
                  type="text"
                  onFocus={() => setfocus(true)}
                  onBlur={() =>
                    setTimeout(() => {
                      setfocus(false);
                    }, 1000)
                  }
                  onChange={(e) => setSearchQuery(e.target.value)}
                  value={searchQuery}
                />
                <button
                  style={{
                    display: "flex",
                    alignItems: "center",
                    minHeight: "17.5px",
                  }}
                >
                  <Images
                    src="/assets/search.svg"
                    alt="Logo"
                    width={20}
                    height={20}
                  />{" "}
                </button>
              </div>
              {focus && (
                <div className="list-container">
                  <ul
                    className="list-group history-list "
                    style={{ height: "90%" }}
                  >
                    {!searchQuery && (
                      <li className="list-group-item success-light-bg d-flex justify-content-between">
                        Recent Searches
                        <span onClick={() => dispatch(deleteSearchKeyword())}>
                          Clear
                        </span>
                      </li>
                    )}
                    {searchQuery === "" ? (
                      <SearchDropdown
                        data={searchKeywords}
                        search={searchQuery}
                      />
                    ) : (
                      <SearchDropdown
                        data={searchResult}
                        search={searchQuery}
                      />
                    )}
                    {searchQuery && (
                      <Link href="/medicines" passHref>
                        <div className="view-all">
                          <button className="text-center"> View All </button>
                        </div>
                      </Link>
                    )}
                    {!searchQuery && (
                      <>
                        <li className="list-group-item  success-light-bg">
                          Trending Products
                        </li>
                        <SearchDropdown
                          data={trendingProducts}
                          search={searchQuery}
                        />
                      </>
                    )}
                  </ul>
                </div>
              )}
            </div>

            <Dropdown
              showData={showData}
              isLoggedIn={isLoggedIn}
              DOM_PINCODEBOC={DOM_PINCODEBOC}
              save_addresses={save_addresses}
              error={error}
              setError={setError}
              pinCode={pinCode}
              setpinCode={setpinCode}
              dispatch={dispatch}
              getAddress={getAddress}
            />
          </div>

          <div>
            <div className="h-icons">
              <div className="icon-content">
                <Images
                  src="/assets/offers.svg"
                  alt="Logo"
                  width={20}
                  className="user-select-cursor"
                  height={20}
                />
                <h3>Offers</h3>
              </div>
              <div
                className="icon-content"
                onClick={() => setIsLoggedIn(!isLoggedIn)}
              >
                <Images
                  src="/assets/exit.png"
                  alt="Logo"
                  width={20}
                  height={20}
                  className="user-select-cursor"
                />
                <h3>Sign in</h3>
              </div>
              <div className="icon-content">
                <Images
                  src="/assets/cart.png"
                  alt="Logo"
                  width={20}
                  className="user-select-cursor"
                  height={20}
                />
                <h3>Cart</h3>
              </div>
            </div>
          </div>
        </Navbar>
      </header>
      <div className=" tabs-container d-flex justify-content-center  ">
        <div className="tabs">
          <Navbar expand="md">
            <NavbarToggler onClick={function noRefCheck() {}} />
            <Collapse navbar>
              <Nav className="me-auto" navbar>
                <NavItem className="active">
                  <NavLink href="/components/">Home</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="https://github.com/reactstrap/reactstrap">
                    medicines
                  </NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="/components/">lab test</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="/components/">store locater</NavLink>
                </NavItem>
                <NavItem>
                  <NavLink href="/components/">COMPARE MEDICINES</NavLink>
                </NavItem>
              </Nav>
            </Collapse>
          </Navbar>
        </div>
      </div>
    </>
  );
}
