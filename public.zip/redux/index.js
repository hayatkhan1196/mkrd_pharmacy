import { combineReducers } from "redux";

// Reducers
import searchReducer from "./reducers/searchReducer";
import addressReducer from "./reducers/addressRducer";


const rootReducer = combineReducers({
    search : searchReducer,
    address: addressReducer
})
// // for reseting root reducer on logout
// const rootReducer = (state, action) => {
//     if (action.type === 'RESET_ALL_DATA') {
//         return appReducers([], action)
//     }
//     return appReducers(state, action) 
// }
export default rootReducer;