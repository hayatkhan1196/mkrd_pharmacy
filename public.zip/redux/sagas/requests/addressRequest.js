import api from "../../api"



// trending search 
export const getAddressApi = (data) => {
    return api.get(`/pincode-details?pincode=${data}`)
}

