import { getCookie } from "commonjs/common"
import api from "../../api"



// trending search 
export const getTrendingProductApi = () => {
    return api.get(`/trending`)
}

// get search result
export const getSearchResultApi = (data) => {
    return api.get(`/products/search?q=${data}`)
}

export const getSearchKeywordApi = () => {
    return api.get(`/recent-search?device_id=${getCookie("deviceId")}`)
}

export const deleteSearchKeywordApi = () => {
    return api.delete(`/recent-search/clearAll`)
}

export const saveSearchKeywordApi = (data) => {
    return api.post('/recent-search', {
        device_id : getCookie("deviceId"),
        keyword: data
    })
}
