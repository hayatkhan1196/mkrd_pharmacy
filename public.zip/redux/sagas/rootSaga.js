import { takeLatest, all } from "redux-saga/effects";
import {
  DELETE_SEARCH_KEYWORD,
  GET_SEARCH_KEYWORD,
  GET_SEARCH_RESULT,
  GET_TRENDING_PRODUCT,
  SAVE_SEARCH_KEYWORD,
} from "redux/action/searchAction";
import {
  handleDeleteSearchKeyword,
  handleGetSearchKeyword,
  handleGetSearchResult,
  handleGetTrendingProduct,
  handleSaveSearchKeyword,
} from "./handlers/searchHandlers";
import { getAddressHandler } from "./handlers/addressHandler";
import { GET_ADDRESS } from "redux/action/AddressAction";

export function* watcherSaga() {
  yield all([
    // search Handlers
    yield takeLatest(GET_TRENDING_PRODUCT, handleGetTrendingProduct),
    yield takeLatest(GET_SEARCH_RESULT, handleGetSearchResult),
    yield takeLatest(SAVE_SEARCH_KEYWORD, handleSaveSearchKeyword),
    yield takeLatest(GET_SEARCH_KEYWORD, handleGetSearchKeyword),
    yield takeLatest(DELETE_SEARCH_KEYWORD, handleDeleteSearchKeyword),
    yield takeLatest(GET_ADDRESS, getAddressHandler),
  ]);
}
